import { Component } from '@angular/core';
import { Routes, Router } from '@angular/router';

interface Product {
  id: number;
  description: string;
}

@Component({
  selector: 'my-app',
  templateUrl: "./app.component.html",
  styles: [`.selected {background-color: cornflowerblue}`]
})

export class AppComponent {
  selectedProduct: Product;

  products: Product[] = [
    { id: 1, description: "iPhone 7" },
    { id: 2, description: "Samsung 7" },
    { id: 3, description: "MS Lumina" }
  ];

  constructor(private _router: Router) { }

  onSelect(prod: Product): void {
    this.selectedProduct = prod;
    this._router.navigate(["/product", prod.id]);
  }
}


