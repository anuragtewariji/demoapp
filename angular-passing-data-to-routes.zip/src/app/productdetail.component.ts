import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'product',
  template: `<b>Product ID : {{productID}}</b>`,
  styles: []
})
export class ProductDetailComponent implements OnInit {
  ngOnInit() { }

  productID: number;

  constructor(private route: ActivatedRoute) {

    this.route.params.subscribe(
      params => this.productID = params['id']
    );
  }
}

