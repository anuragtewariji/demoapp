import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AngularSlickgridModule } from 'angular-slickgrid';
import { GridThreeComponent } from './grid-three.component';

@NgModule({
  imports: [
    CommonModule,
    AngularSlickgridModule
  ],
  declarations: [GridThreeComponent]
})
export class GridThreeModule { }