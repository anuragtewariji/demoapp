import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {GridOneComponent}  from './grid-one.component';
import { AngularSlickgridModule } from 'angular-slickgrid';


@NgModule({
  imports: [
    CommonModule,
    AngularSlickgridModule
  ],
  declarations: [GridOneComponent]
})
export class GridOneModule { }