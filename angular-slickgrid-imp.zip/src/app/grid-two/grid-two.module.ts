import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AngularSlickgridModule } from 'angular-slickgrid';
import {GridTwoComponent} from './grid-two.component';

@NgModule({
  imports: [
    CommonModule,
    AngularSlickgridModule
  ],
  declarations: [GridTwoComponent]
})
export class GridTwoModule { }