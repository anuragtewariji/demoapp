import { Component } from '@angular/core';
import * as XLSX from 'xlsx';
import * as Excel from 'exceljs';

type dataType = any[][];

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  public name = 'We are here to read Xl file data';
  public isDownload = false;
  public data: dataType = [];
  public wopts: XLSX.WritingOptions = { bookType: 'xlsx', type: 'array' };

  public readFileAndGetJson(ev: any): void {
    let workBook = null;
    let jsonData = null;
    const reader = new FileReader();
    console.log('Imorted file', ev.target.files);
    const file = ev.target.files[0];
    reader.onload = (event) => {
      const data = reader.result;
      workBook = XLSX.read(data, { type: 'binary' });
      jsonData = workBook.SheetNames.reduce((initial, name) => {
        const sheet = workBook.Sheets[name];
        initial[name] = XLSX.utils.sheet_to_json(sheet);
        return initial;
      }, {});
      const dataString = JSON.stringify(jsonData);
      document.getElementById('output').innerHTML = dataString
        .slice(0, 300)
        .concat('...');
      this.jsonDownload(jsonData);
    };
    reader.readAsBinaryString(file);
  }

  public readXlFile(evt: any): void {
    /* wire up file reader */
    let jsonData = null;
    const target: DataTransfer = <DataTransfer>evt.target;
    console.log('Imported files', target.files);
    if (target.files.length !== 1) throw new Error('Cannot use multiple files');
    const reader: FileReader = new FileReader();
    reader.onload = (e: any) => {
      /* read workbook */
      const bstr: string = e.target.result;
      const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });

      /** get all sheet names */
      console.log(wb.SheetNames);

      /* get first sheet */
      const wsname: string = wb.SheetNames[1];
      const ws: XLSX.WorkSheet = wb.Sheets[wsname];

      /* save data */
      // this.data = <dataType>XLSX.utils.sheet_to_json(ws, { header: 1 });
      // console.log(ws);
      jsonData = wb.SheetNames.reduce((initial, name) => {
        const sheet = wb.Sheets[name];
        initial[name] = <dataType>(
          XLSX.utils.sheet_to_json(sheet, { header: 1 })
        );
        return initial;
      }, {});
      const dataString = JSON.stringify(jsonData);
      this.jsonDownload(dataString);
    };
    reader.readAsBinaryString(target.files[0]);
  }

  public readFileUsingExcelJS(evt): void {
    console.log(evt.target);
    debugger;
    var workbook = new Excel.Workbook();
    const filename = evt.target.files;
    workbook.xlsx.readFile(filename).then(function () {
      var worksheet = workbook.getWorksheet('one');
      worksheet.eachRow({ includeEmpty: true }, function (row, rowNumber) {
        console.log('Row ' + rowNumber + ' = ' + JSON.stringify(row.values));
      });
    });
  }
  /** Method to export table data in xl file */
  public export(): void {
    /* generate worksheet */
    const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(this.data);

    /* generate workbook and add the worksheet */
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

    /* save to file */
    XLSX.writeFile(wb, 'SampleJS.xlsx');
  }

  /** method to download data in JSON format */
  private jsonDownload(data: any): void {
    this.isDownload = true;
    setTimeout(() => {
      const el = document.querySelector('#download2');
      el.setAttribute(
        'href',
        `data:text/json;charset=utf-8,${encodeURIComponent(data)}`
      );
      el.setAttribute('download', 'xlsxtojson.json');
    }, 1000);
  }
}
