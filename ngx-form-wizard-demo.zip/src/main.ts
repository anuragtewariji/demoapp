import 'zone.js/dist/zone';
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { bootstrapApplication } from '@angular/platform-browser';

import {
  IStepperOptions,
  IWizardStep,
  FormWizardModule,
} from 'ngx-form-wizard';

import { Step1Component } from './steps/step1.component';
import { Step2Component } from './steps/step2.component';
import { Step3Component } from './steps/step3.component';
import { Step4Component } from './steps/step4.component';

@Component({
  selector: 'my-app',
  standalone: true,
  imports: [
    CommonModule,
    FormWizardModule,
    Step1Component,
    Step2Component,
    Step3Component,
    Step4Component,
  ],
  template: `
    <ngx-form-wizard
      [steps]="steps"
      [stepperOptions]="stepperOptions">
    </ngx-form-wizard>
  `,
})
export class App {
  name = 'Angular';

  steps: IWizardStep[] = [
    {
      id: 1,
      title: 'Personal Info',
      description: 'Provide your Personal details',
      data: null,
      component: Step1Component,
    },
    {
      id: 2,
      title: 'Education',
      description: 'Provide your Eduction details',
      data: null,
      component: Step2Component,
    },
    {
      id: 3,
      title: 'Work Experience',
      description: 'Provide your Work Experience details',
      data: null,
      component: Step3Component,
    },
    {
      id: 4,
      title: 'Review',
      description: 'Please review your details before submitting',
      data: null,
      component: Step4Component,
    },
  ];

  stepperOptions: IStepperOptions = {
    custom: false,
    position: 'right',
  };
}

bootstrapApplication(App);
