import { Component } from '@angular/core';
import { FormControl, ReactiveFormsModule, Validators } from '@angular/forms';
import {
  FormWizardService,
  FormWizardStepBaseComponent,
} from 'ngx-form-wizard';

@Component({
  selector: 'step1',
  standalone: true,
  imports: [ReactiveFormsModule],
  template: `
    <form [formGroup]="form">
      <div>
        <label>First Name</label>
        <input type="text" formControlName="firstName">
      </div>
      <div>
        <label>Last Name</label>
        <input type="text" formControlName="lastName">
      </div>
      <div>
        <label>Gender</label>
        <div>
          <span>
            <input id="male" type="radio" value="male" formControlName="gender">
            <label for="male">Male</label>
          </span>
          <span>
            <input id="female" type="radio" value="female" formControlName="gender">
            <label for="female">Female</label>
          </span>
        </div>
      </div>
      <div>
        <label>Date of Birth</label>
        <input type="date" formControlName="dob">
      </div>
    </form>
  `,
})
export class Step1Component extends FormWizardStepBaseComponent {
  constructor(private wizardService: FormWizardService) {
    const formcontrols = {
      firstName: new FormControl('', [Validators.required]),
      lastName: new FormControl('', [Validators.required]),
      gender: new FormControl('', [Validators.required]),
      dob: new FormControl('', [Validators.required]),
    };
    super(1, wizardService.getSteps(), true, formcontrols);
  }
}
