import { Component } from '@angular/core';
import { FormControl, ReactiveFormsModule, Validators } from '@angular/forms';
import {
  FormWizardService,
  FormWizardStepBaseComponent,
} from 'ngx-form-wizard';

@Component({
  selector: 'step2',
  standalone: true,
  imports: [ReactiveFormsModule],
  template: `
    <form [formGroup]="form">
      <div>
        <label>College</label>
        <input type="text" formControlName="college">
      </div>
      <div>
        <label>Course</label>
        <input type="text" formControlName="course">
      </div>
      <div>
        <label>Year of Passing</label>
        <input type="number" formControlName="yop">
      </div>
      <div>
        <label>CGPA</label>
        <input type="number" formControlName="cgpa">
      </div>
    </form>
  `,
})
export class Step2Component extends FormWizardStepBaseComponent {
  constructor(private wizardService: FormWizardService) {
    const formcontrols = {
      college: new FormControl('', [Validators.required]),
      course: new FormControl('', [Validators.required]),
      yop: new FormControl(null, [Validators.required]),
      cgpa: new FormControl(null, [Validators.required]),
    };
    super(2, wizardService.getSteps(), true, formcontrols);
  }
}
