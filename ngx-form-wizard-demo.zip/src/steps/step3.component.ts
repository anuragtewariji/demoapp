import { Component } from '@angular/core';
import { FormControl, ReactiveFormsModule, Validators } from '@angular/forms';
import {
  FormWizardService,
  FormWizardStepBaseComponent,
} from 'ngx-form-wizard';

@Component({
  selector: 'step3',
  standalone: true,
  imports: [ReactiveFormsModule],
  template: `
    <form [formGroup]="form">
      <div>
        <label>Company</label>
        <input type="text" formControlName="company">
      </div>
      <div>
        <label>Designation</label>
        <input type="text" formControlName="designation">
      </div>
      <div>
        <label>Years of Experience</label>
        <input type="number" formControlName="yoe">
      </div>
      <div>
        <label>Skills</label>
        <input type="text" formControlName="skills">
      </div>
    </form>
  `,
})
export class Step3Component extends FormWizardStepBaseComponent {
  constructor(private wizardService: FormWizardService) {
    const formcontrols = {
      company: new FormControl('', [Validators.required]),
      designation: new FormControl('', [Validators.required]),
      yoe: new FormControl(null, [Validators.required]),
      skills: new FormControl('', [Validators.required]),
    };
    super(3, wizardService.getSteps(), true, formcontrols);
  }
}
