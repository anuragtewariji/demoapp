import { Component } from '@angular/core';
import data  from './data.json';

@Component({
  selector: 'my-app',
  template: `<h1>Hello Angular Lovers!</h1>
<p>Look at this JSON</p>
<pre>
  {{json | json}}}
</pre>`
})
export class AppComponent  {
  json:any = data;
  name = 'Angular';
  constructor() {
    console.log(this.json);
  }
}