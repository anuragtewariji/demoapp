import { Component } from '@angular/core';

@Component({
  selector: 'frame-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class FrameHeaderComponent {

}
