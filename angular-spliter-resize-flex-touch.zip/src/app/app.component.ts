import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.scss"],
  host: { "(window:resize)": "changeFlexSizeBox($event)" }
})
export class AppComponent implements OnInit {
  flex = { size: { nav: 50, cut: 6, box: { h: 0, w: 0 }, row: { h: 0, w: [0, 0] }, col: { h: [0, 0], w: 0 } }, diff: { w: 0, h: 0}, show: [ true, true ], flow: { col: false, rev: false } };
  ngOnInit() {
    this.flex.size.box = { h: window.innerHeight - this.flex.size.nav, w: window.innerWidth };
    this.flex.size.row = { h: this.flex.size.box.h, w: [ (this.flex.size.box.w - this.flex.size.cut) / 2, this.flex.size.box.w - this.flex.size.cut - (this.flex.size.box.w - this.flex.size.cut) / 2 ] };
    this.flex.size.col = { h: [ (this.flex.size.box.h - this.flex.size.cut) / 2, this.flex.size.box.h - this.flex.size.cut - (this.flex.size.box.h - this.flex.size.cut) / 2 ], w: this.flex.size.box.w };
  }
  onDrag4cutStart(event: DragEvent) {
    this.changeFlexSizeCut(0, event);
  }
  onDrag4cutEnd(event: DragEvent) {
    this.changeFlexSizeCut(1, event);
  }
  setSizes2style(isColumn, i) {
    if ( ( isColumn && this.flex.show[0] && this.flex.show[1] && !this.flex.flow.col ) || ( isColumn && ( !this.flex.show[0] || !this.flex.show[1] ) ) ) {
      return this.flex.size.row.h;
    } else if ( ( !isColumn && this.flex.show[0] && this.flex.show[1] && this.flex.flow.col ) || ( !isColumn && ( !this.flex.show[0] || !this.flex.show[1] ) ) ) {
      return this.flex.size.box.w;
    } else if ( isColumn && this.flex.show[0] && this.flex.show[1] && this.flex.flow.col ) {
      return this.flex.size.col.h[i];
    } else if ( !isColumn && this.flex.show[0] && this.flex.show[1] && !this.flex.flow.col ) {
      return this.flex.size.row.w[i];
    } 
  }
  changeFlexShow(i) {
    this.flex.show[i] = !this.flex.show[i];
  }
  changeFlexFlow() {
    if ( ( !this.flex.flow.col && !this.flex.flow.rev ) || ( !this.flex.flow.col && this.flex.flow.rev ) ) {
      this.flex.flow.col = !this.flex.flow.col;
    } else if ( ( this.flex.flow.col && !this.flex.flow.rev ) || ( this.flex.flow.col && this.flex.flow.rev ) ) {
      this.flex.flow.col = !this.flex.flow.col;
      this.flex.flow.rev = !this.flex.flow.rev;
    }
  }
  changeFlexSizeCut(i, ev) {
    if (i === 0) {
      this.flex.diff.w = this.flex.flow.col ? 0 : ev.x * -1;
      this.flex.diff.h = this.flex.flow.col ? ev.y * -1 : 0;
    } else if (i === 1) {
      this.flex.diff.w += this.flex.flow.col ? 0 : ev.x;
      this.flex.diff.h += this.flex.flow.col ? ev.y : 0;
      if (!this.flex.flow.rev) {
        this.flex.size.row.w[0] += this.flex.diff.w;
        this.flex.size.row.w[1] -= this.flex.diff.w;
        this.flex.size.col.h[0] += this.flex.diff.h;
        this.flex.size.col.h[1] -= this.flex.diff.h;
      } else {
        this.flex.size.row.w[0] -= this.flex.diff.w;
        this.flex.size.row.w[1] += this.flex.diff.w;
        this.flex.size.col.h[0] -= this.flex.diff.h;
        this.flex.size.col.h[1] += this.flex.diff.h;
      }
    }
  }
  changeFlexSizeBox(event) {
    this.flex.size.row.h += window.innerHeight - this.flex.size.nav - this.flex.size.box.h;
    this.flex.size.row.w[0] += ( window.innerWidth - this.flex.size.box.w ) / 2;
    this.flex.size.row.w[1] += ( window.innerWidth - this.flex.size.box.w ) / 2;
    this.flex.size.col.h[0] += ( window.innerHeight - this.flex.size.nav - this.flex.size.box.h ) / 2;
    this.flex.size.col.h[1] += ( window.innerHeight - this.flex.size.nav - this.flex.size.box.h ) / 2;
    this.flex.size.col.w += window.innerWidth - this.flex.size.box.w;
    this.flex.size.box.h += window.innerHeight - this.flex.size.nav - this.flex.size.box.h;
    this.flex.size.box.w += window.innerWidth - this.flex.size.box.w;
  }
}
