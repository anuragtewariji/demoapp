import React from "react";
import Graph from './graph';

export default function App() {

  return (
    <div>
        <Graph />
    </div>
  )
}