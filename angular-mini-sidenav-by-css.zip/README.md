# angular-mini-sidenav-by-css

[Edit on StackBlitz ⚡️](https://stackblitz.com/edit/angular-mini-sidenav-by-css)