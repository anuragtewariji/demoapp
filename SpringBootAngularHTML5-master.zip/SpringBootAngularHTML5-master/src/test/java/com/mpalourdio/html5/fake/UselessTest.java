package com.mpalourdio.html5.fake;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class UselessTest {

    @Test
    void testOneEqualsOne() {
        assertEquals(1, 1);
    }
}
