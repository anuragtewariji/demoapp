import { Component } from '@angular/core';

@Component({
  selector: 'history',
  template: `
    <h5>History Component</h5>
  `
})
export class HistoryComponent {}
