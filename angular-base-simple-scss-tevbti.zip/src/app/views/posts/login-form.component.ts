import { Component } from '@angular/core';

@Component({
  selector: 'login-form',
  template: `
    <h5>Login Form Component</h5>
  `
})
export class LoginFormComponent {}
