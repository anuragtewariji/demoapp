import { Component } from '@angular/core';

@Component({
  selector: 'web-design',
  template: `
    <h5>Web Design Component</h5>
  `
})
export class WebDesignComponent {}
