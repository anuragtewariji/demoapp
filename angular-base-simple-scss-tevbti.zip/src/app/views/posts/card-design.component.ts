import { Component } from '@angular/core';

@Component({
  selector: 'card-design',
  template: `
    <h5>Card Design Component</h5>
  `
})
export class CardDesignComponent {}
