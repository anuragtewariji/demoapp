import { Component } from '@angular/core';

@Component({
  selector: 'analytics',
  template: `
    <h5>Analytics Component</h5>
  `
})
export class AnalyticsComponent {}
