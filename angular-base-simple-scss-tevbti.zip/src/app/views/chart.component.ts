import { Component } from '@angular/core';

@Component({
  selector: 'chart',
  template: `
    <h5>Chart Component</h5>
  `
})
export class ChartComponent {}
