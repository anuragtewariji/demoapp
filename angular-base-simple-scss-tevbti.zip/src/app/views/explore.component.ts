import { Component } from '@angular/core';

@Component({
  selector: 'explore',
  template: `
    <h5>Explore Component</h5>
  `
})
export class ExploreComponent {}
