import { Component } from '@angular/core';

@Component({
  selector: 'setting',
  template: `
    <h5>Setting Component</h5>
  `
})
export class SettingComponent {}
