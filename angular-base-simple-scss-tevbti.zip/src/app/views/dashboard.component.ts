import { Component } from '@angular/core';

@Component({
  selector: 'dashboard',
  template: `
    <h5>Dashboard Component</h5>
  `
})
export class DashboardComponent {}
