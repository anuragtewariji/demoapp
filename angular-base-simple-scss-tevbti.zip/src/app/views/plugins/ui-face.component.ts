import { Component } from '@angular/core';

@Component({
  selector: 'ui-face',
  template: `
    <h5>Card UI Face Component</h5>
  `
})
export class UIFaceComponent {}
