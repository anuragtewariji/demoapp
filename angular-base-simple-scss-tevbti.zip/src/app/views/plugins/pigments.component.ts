import { Component } from '@angular/core';

@Component({
  selector: 'pigments',
  template: `
    <h5>Pigments Component</h5>
  `
})
export class PigmentsComponent {}
