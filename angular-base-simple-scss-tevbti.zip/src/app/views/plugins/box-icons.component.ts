import { Component } from '@angular/core';

@Component({
  selector: 'box-icons',
  template: `
    <h5>Box Icons Component</h5>
  `
})
export class BoxIconsComponent {}
