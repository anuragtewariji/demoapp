import { Component } from '@angular/core';

@Component({
  selector: 'html-n-css',
  template: `
    <h5>HTML & CSS Component</h5>
  `
})
export class HTML_n_CSSComponent {}
