import { Component } from '@angular/core';

@Component({
  selector: 'php-n-mysql',
  template: `
    <h5>PHP & MySQL Component</h5>
  `
})
export class PHP_n_MySQLComponent {}
