import { Component } from '@angular/core';

@Component({
  selector: 'javascript',
  template: `
    <h5>Javascript Component</h5>
  `
})
export class JavascriptComponent {}
