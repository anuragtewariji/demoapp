import { Component } from '@angular/core';

@Component({
  selector: 'default',
  template: `
    <div class="text-sidebar">Sidebar</div>
  `
})
export class DefaultComponent {}
