import { Directive, OnInit, OnDestroy, ElementRef ,Input } from '@angular/core';
import { ThemeService } from './theme.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { Theme } from './symbols';

@Directive({
  selector: '[theme]'
})
export class ThemeDirective implements OnInit {

  private _styleObj;
  @Input('styleObj')
  set styleObj(value){
    if(value) {
      this.updateTheme(value);
    }
  }

  constructor(
    private _elementRef: ElementRef
  ) {}

  ngOnInit() {
  }

  ngOnDestroy() {
  }

  updateTheme(properties) {
    // project properties onto the element
    for (const key in properties) {
      this._elementRef.nativeElement.style.setProperty(key, properties[key]);
    }
  }

}
