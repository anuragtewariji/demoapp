import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { ThemeModule, lightTheme, darkTheme } from './theme';
import { ThemeDirective } from './theme/theme.directive';
@NgModule({
  imports:      [
    BrowserModule,
  ],
  declarations: [ AppComponent , ThemeDirective ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
