import { Component } from '@angular/core';

@Component({
  selector: 'app-test-one',
  templateUrl: './test-one.component.html'
})
export class TestOneComponent {
  constructor() {}
}
