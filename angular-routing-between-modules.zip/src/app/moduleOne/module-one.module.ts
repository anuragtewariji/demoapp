import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModuleOneRoutingModule } from './module-one-routing';

@NgModule({
  declarations: [],
  imports: [CommonModule, ModuleOneRoutingModule],
})
export class ModuleOneModule {}
