import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModuleTwoRoutingModule } from './module-two.routing';

@NgModule({
  declarations: [],
  imports: [CommonModule, ModuleTwoRoutingModule],
})
export class ModuleTwoModule {}
