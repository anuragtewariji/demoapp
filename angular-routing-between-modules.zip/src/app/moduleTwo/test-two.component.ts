import { Component } from '@angular/core';

@Component({
  selector: 'app-test-two',
  templateUrl: './test-two.component.html'
})
export class TestTwoComponent {
  constructor() {}
}
