import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModuleThreeRoutingModule } from './module-three.routing';

@NgModule({
  declarations: [],
  imports: [CommonModule, ModuleThreeRoutingModule],
})
export class ModuleThreeModule {}
