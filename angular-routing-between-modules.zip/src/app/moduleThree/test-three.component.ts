import { Component } from '@angular/core';

@Component({
  selector: 'app-test-three',
  templateUrl: './test-three.component.html',
})
export class TestThreeComponent {
  constructor() {}
}
