# angular-routing-between-modules

[Edit on StackBlitz ⚡️](https://stackblitz.com/edit/angular-routing-between-modules)