import { Component, VERSION } from '@angular/core';
import { AngularSplitModule } from 'angular-split';

@Component({
  selector: 'my-app',
  standalone: true,
  imports: [AngularSplitModule],
  templateUrl: './app.component.html',
})
export class AppComponent {
  version = VERSION.full;
}
