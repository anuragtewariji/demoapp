import { Component } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { MatIconRegistry } from '@angular/material';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent  {
  name = 'Angular';

  constructor(public matIconRegistry: MatIconRegistry, sanitizer: DomSanitizer) {
      this.matIconRegistry.addSvgIcon('lt-google', 
      sanitizer.bypassSecurityTrustResourceUrl('/assets/lt-google.svg'));

      this.matIconRegistry.addSvgIcon('lt-asana', 
      sanitizer.bypassSecurityTrustResourceUrl('/assets/lt-asana.svg'));

      this.matIconRegistry.addSvgIcon('lt-google-plain', 
      sanitizer.bypassSecurityTrustResourceUrl('/assets/plain/lt-google_plain.svg'));

      this.matIconRegistry.addSvgIcon('lt-asana-plain', 
      sanitizer.bypassSecurityTrustResourceUrl('/assets/plain/lt-asana_plain.svg'));

      this.matIconRegistry.addSvgIcon('lt-call', 
      sanitizer.bypassSecurityTrustResourceUrl('/assets/test/call.svg'));

      this.matIconRegistry.addSvgIcon('lt-conversation', 
      sanitizer.bypassSecurityTrustResourceUrl('/assets/test/conversation.svg'));

      this.matIconRegistry.addSvgIcon('lt-creative', 
      sanitizer.bypassSecurityTrustResourceUrl('/assets/test/creative.svg'));

      this.matIconRegistry.addSvgIcon('lt-interview', 
      sanitizer.bypassSecurityTrustResourceUrl('/assets/test/interview.svg'));

      this.matIconRegistry.addSvgIcon('lt-target', 
      sanitizer.bypassSecurityTrustResourceUrl('/assets/test/target.svg'));

      this.matIconRegistry.addSvgIcon('lt-teamwork', 
      sanitizer.bypassSecurityTrustResourceUrl('/assets/test/teamwork.svg'));
  }
}
