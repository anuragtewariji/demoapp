import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { HelloComponent } from './hello.component';

import { 
  MatIconModule,
  MatIconRegistry
} from '@angular/material';

@NgModule({
  imports: [ 
    BrowserModule,
    HttpClientModule, 
    FormsModule, 
    MatIconModule 
  ],
  declarations: [ AppComponent, HelloComponent ],
  bootstrap:    [ AppComponent ],
  providers:    [ MatIconRegistry ]
})
export class AppModule { }
