import { Component } from "@angular/core";

@Component({
  selector: "about",
  template: ` <p>About Page.</p> `,
  styles: [],
})
export class AboutComponent { }
