import { Component } from "@angular/core";

@Component({
  selector: "locations",
  template: ` <p>Locations Page</p> `,
  styles: [],
})
export class LocationsComponent { }
