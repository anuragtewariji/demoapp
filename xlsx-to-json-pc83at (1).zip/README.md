# xlsx-to-json-xh7q8q

[Edit on StackBlitz ⚡️](https://stackblitz.com/edit/xlsx-to-json-xh7q8q)