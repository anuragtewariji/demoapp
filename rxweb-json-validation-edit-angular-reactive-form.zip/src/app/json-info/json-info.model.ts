import {  json, } from "@rxweb/reactive-form-validators"
export class JsonInfo {

	@json() 
	locationJson: string;

}
