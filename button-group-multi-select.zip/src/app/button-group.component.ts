
import { Component, Input, Output, EventEmitter, QueryList, ElementRef, AfterContentInit, ContentChildren } from '@angular/core';
import { FocusKeyManager } from '@angular/cdk/a11y';

import { ButtonGroupService, ButtonGroupButtonClickEvent } from './button-group.service';

import { ButtonGroupButton } from './button-group-button.component';

export class ButtonGroupChangeEvent {
  source: ButtonGroup;
  nativeEvent: Event;
  value: string;
}

@Component({
  selector: 'button-group',
  templateUrl: './button-group.component.html',
  styleUrls: [ './button-group.component.css' ],
  host: {
    '[attr.tabindex]': '0',
    '[attr.role]': '"group"',
    '[attr.aria-label]': 'label',
    '(focus)': 'onFocus($event)',
    '(keydown)': 'onKeydown($event)'
  },
  providers: [ButtonGroupService]
})
export class ButtonGroup implements AfterContentInit  {
  @Input()
  value: string;

  @Input()
  label: string;

  @Output() 
  change: EventEmitter<ButtonGroupChangeEvent> = new EventEmitter();

  @ContentChildren(ButtonGroupButton) private buttons: QueryList<ButtonGroupButton>;

  private keyManager: FocusKeyManager<ButtonGroupButton>;

  constructor (private buttonGroupService: ButtonGroupService) {}

  ngAfterContentInit(): void {
    this.keyManager = new FocusKeyManager(this.buttons)
      .withWrap();

    this.buttonGroupService.currentEvent.subscribe(($event: ButtonGroupButtonClickEvent) => {
      if ($event === null) return;

      const buttons = this.buttons.toArray();
      const index = buttons.findIndex(button => button.value === $event.value);
      this.toggleActiveItem(index);
      this.keyManager.updateActiveItem(index);
      this.emitChangeEvent($event.nativeEvent, $event.value);
    });
  }

  onFocus($event): void {
    const buttons = this.buttons.toArray();
    const index = buttons.findIndex(button => !button.disabled);
    const button = buttons[index];

    if (button) {
      button.focus()
    }

    this.keyManager.updateActiveItem(index);
  }

  toggleActiveItem(index: number): void {
    const buttons = this.buttons.toArray();
    buttons[index].active = !buttons[index].active;
  }

  getActiveItem(): ButtonGroupButton {
    const buttons = this.buttons.toArray();
    return buttons.find((b, i) => i === this.keyManager.activeItemIndex);
  }

  onKeydown($event): void {
    this.keyManager.onKeydown($event);
    //this.toggleActiveItem(this.keyManager.activeItemIndex);
    //const button = this.getActiveItem();
    //this.emitChangeEvent($event, button.value)
  }

  emitChangeEvent($event: Event, value: string): void {
    const event = new ButtonGroupChangeEvent();

    event.source = this;
    event.nativeEvent = $event;
    event.value = value;

    this.change.emit(event);
  }
}
