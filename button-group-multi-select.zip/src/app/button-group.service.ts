import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export class ButtonGroupButtonClickEvent {
  nativeEvent: Event;
  value: string;
}

@Injectable()
export class ButtonGroupService {
  private eventSource = new BehaviorSubject<ButtonGroupButtonClickEvent | null>(null);
  currentEvent = this.eventSource.asObservable();

  emitChange($event: ButtonGroupButtonClickEvent): void {
    this.eventSource.next($event);
  }
}