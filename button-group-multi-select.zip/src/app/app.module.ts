import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { ButtonGroupButton } from './button-group-button.component';
import { ButtonGroup } from './button-group.component';

import { AppComponent } from './app.component';

@NgModule({
  imports:      [ BrowserModule, FormsModule ],
  declarations: [ AppComponent, ButtonGroupButton, ButtonGroup ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
