import { Component, ElementRef, Input } from '@angular/core';
import { FocusableOption } from '@angular/cdk/a11y';

import { ButtonGroupService, ButtonGroupButtonClickEvent } from './button-group.service';

@Component({
  selector: '[button-group-button]',
  templateUrl: './button-group-button.component.html',
  styleUrls: [ './button-group-button.component.css' ],
  host: {
    '[attr.role]': '"option"',
    '[attr.type]': '"button"',
    '[attr.aria-selected]': 'active || null',
    '[attr.tabindex]': '-1',
    '[attr.aria-disabled]': 'disabled || null',
    '(click)': 'onClick($event)'
  }
})
export class ButtonGroupButton implements FocusableOption {
  @Input()
  active = false;

  @Input()
  value: string;

  @Input()
  disabled: boolean;

  constructor (public el: ElementRef, private buttonGroupService: ButtonGroupService) {}

  focus (): void {
    this.el.nativeElement.focus();
  }

  onClick ($event: Event): void {
    const event = new ButtonGroupButtonClickEvent();
    event.nativeEvent = $event;
    event.value = this.value;

    this.buttonGroupService.emitChange(event)
  }
}
